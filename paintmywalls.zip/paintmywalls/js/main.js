// swiper    
var mySwiper = new Swiper('.galleryswipper', {
   effect: '',
   loop: true,
   speed: 1000,
   slidesPerView: 4,
   effect: "coverflow",
   navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev'
   },
   pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: 'true'
   },
});
var mySwiper = new Swiper('.swiper-containerComment', {
  effect: '',
  loop: true,
  speed: 1000,
  slidesPerView: 1,
  //effect: "coverflow",
  navigation: {
     nextEl: '.swiper-button-next',
     prevEl: '.swiper-button-prev'
  },
  pagination: {
     el: '.swiper-pagination',
     type: 'bullets',
     clickable: 'true'
  },
});

  $(window,document).scroll(function(){
        var sticky = $('.navbar'),
            scroll = $(window,document).scrollTop();
      
        if (scroll >= 100) sticky.addClass('fixed-top');
        else sticky.removeClass('fixed-top');
      });
  
    $(".navbar-nav .nav-item").hover(function () {
        $(this).find(".dropdown-menu").slideDown("slow");
    }, function(){
        $(this).find(".dropdown-menu").slideUp("fast");
    });
    $(function () {
    
      var maxL = 200;
      
      $('.card-title').each(function () {
          
          var text = $(this).text();
          if(text.length > maxL) {
              
              var begin = text.substr(0, maxL),
                  end = text.substr(maxL);
  
              $(this).html(begin)
                  .append($('<a class="readmore"/>').attr('href', 'JavaScript:void(0)').html("..."))
                  .append($('<div class="hidden" />').html(end));
                  
              
          }
          
          
      });
              
      $(document).on('click', '.readmore', function () {
              // $(this).next('.readmore').fadeOut("400");
          $(this).next('.hidden').slideToggle(400);
          $(this).toggleClass("active")
      })        
      
      
  })
    
        
        
